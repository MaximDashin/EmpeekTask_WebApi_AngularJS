﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpeekTask.Models
{
    public class InformationViewModel
    {
        public InformationViewModel()
        {
            FolderNames = new List<string>();
            FileNames = new List<string>();
        }
        public string CurentFolder { get; set; }
        public string ParentFolder { get; set; }
        public int Less10 { get; set; }
        public int From10To50 { get; set; }
        public int More100 { get; set; }
        public List<string> FolderNames { get; set; }
        public List<string> FileNames { get; set; }
    }
}
