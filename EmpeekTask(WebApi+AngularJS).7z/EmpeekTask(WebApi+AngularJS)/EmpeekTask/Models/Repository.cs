﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using WebGrease.Css.Extensions;

namespace EmpeekTask.Models
{
    public class Repository : IRepository
    {
        public InformationViewModel GetLogicalDrives()
        {
            var logicalDrives = DriveInfo.GetDrives()
                .Where(e => e.DriveType == DriveType.Fixed || e.DriveType == DriveType.Removable)
                .Select(e => e.Name)
                .ToList();

            return new InformationViewModel
            {
                CurentFolder = null,
                FolderNames = logicalDrives,
                FileNames = null,
                From10To50 = 0,
                Less10 = 0,
                More100 = 0,
                ParentFolder = null
            };
        }

        public InformationViewModel GetInformation(string id)
        {
            var model = new InformationViewModel { CurentFolder = id };

            var parentFolder = new DirectoryInfo(model.CurentFolder).Parent;
            if (parentFolder != null)
                model.ParentFolder = parentFolder.FullName;

            var directories =
                Directory.GetDirectories(model.CurentFolder)
                    .Select(dir => new DirectoryInfo(dir))
                    .Where(
                        dir =>
                            (dir.Attributes & FileAttributes.System) == 0 &&
                            (dir.Attributes & FileAttributes.Hidden) == 0);
            foreach (var directory in directories)
            {
                model.FolderNames.Add(directory.Name);
            }

            model.Less10 = 0;
            model.From10To50 = 0;
            model.More100 = 0;

            var files =
                Directory.GetFiles(model.CurentFolder)
                    .Select(file => new FileInfo(file))
                    .Where(
                        file =>
                            (file.Attributes & FileAttributes.System) == 0 &&
                            (file.Attributes & FileAttributes.Hidden) == 0);
            foreach (var fileInfo in files)
            {
                model.FileNames.Add(fileInfo.Name);
                if (fileInfo.Length <= (1024*1024*10))
                    model.Less10++;
                else if (fileInfo.Length > (1024 * 1024 * 10) && fileInfo.Length <= (1024 * 1024 * 50))
                    model.From10To50++;
                else if (fileInfo.Length > (1024 * 1024 * 100))
                    model.More100++;
            }

            return model;
        }
    }

}