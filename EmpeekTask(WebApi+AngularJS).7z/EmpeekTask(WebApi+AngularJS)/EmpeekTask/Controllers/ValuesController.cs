﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using EmpeekTask.Models;

namespace EmpeekTask.Controllers
{
    public class ValuesController : ApiController
    {
        private readonly IRepository _repository;

        public ValuesController(IRepository repository)
        {
            _repository = repository;
        }

        public IHttpActionResult Get()
        {
            return Ok(_repository.GetLogicalDrives());
        }

        public InformationViewModel Get([FromUri] string id)
        {
            var result = _repository.GetInformation(id+"\\");
            return result;
        }
        
    }
}
