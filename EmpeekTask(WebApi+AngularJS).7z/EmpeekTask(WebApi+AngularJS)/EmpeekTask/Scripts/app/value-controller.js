﻿angular.module("EmpeekApp", [])
    .controller("ValueController", function($scope, $http) {
        $scope.less10 = 0;
        $scope.from10to50 = 0;
        $scope.more100 = 0;
        $scope.parentFolder = null;
        $scope.currentPath = null;
        $scope.folders = [];
        $scope.files = [];
        $scope.canGoBack = false;

        var showData = function (data)
        {
            $scope.less10 = data.Less10;
            $scope.from10to50 = data.From10To50;
            $scope.more100 = data.More100;

            if (data.CurentFolder != null)
            {
                $scope.currentPath = data.CurentFolder;
            } else
            {
                $scope.currentPath = "";
            }

            $scope.parentFolder = data.ParentFolder;
            $scope.canGoBack = data.ParentFolder !== null ? true : false;

            $scope.folders = data.FolderNames;
            $scope.files = data.FileNames;
        };

        $scope.GetAllData = function() {
            $http.get("/api/values").success(function(data) {
                showData(data);
            });
        };

        $scope.GetSomeData = function (path) {
            $http.get("/api/values?id=" + path).success(function (data)
            {
                showData(data);
            });
        };


    });



//var apiPath = "/api/values?id=";

//var GetAllData = function ()
//{
//    $.ajax({
//        url: '/api/values',
//        type: 'GET',
//        dataType: 'json',
//        success: function (data)
//        {
//            ShowData(data);
//        }
//    });
//}

//var GetSomeData = function (path)
//{
//    $.ajax({
//        url: apiPath + path,
//        type: 'GET',
//        dataType: 'json',
//        contentType: 'application/json; charset=utf-8',
//        success: function (data)
//        {
//            ShowData(data);
//        }
//    });
//};

//var ShowData = function (data)
//{
//    $("#less10").text(data.Less10);
//    $("#from10to50").text(data.From10To50);
//    $("#more100").text(data.More100);

//    if (data.CurentFolder != null)
//    {
//        $("#currentPath").text(data.CurentFolder);
//    } else
//    {
//        $("#currentPath").text("Root folder");
//        data.CurentFolder = "";
//    }

//    $("#foldersList").empty();
//    if (data.ParentFolder != null)
//    {
//        var liElem1 = $('<li />');
//        var hrefElem1 = $('<a />', { href: "#" });
//        hrefElem1.text(" ... ");
//        hrefElem1.click(function ()
//        {
//            GetSomeData(encodeURIComponent(data.ParentFolder));
//        });
//        liElem1.append(hrefElem1);
//        $("#foldersList").append(liElem1);
//    }
//    for (let i = 0; i < data.FolderNames.length; i++)
//    {
//        var liElem2 = $('<li />');
//        var hrefElem2 = $('<a />', { href: "#" });
//        hrefElem2.text(data.FolderNames[i]);
//        hrefElem2.click(function ()
//        {
//            GetSomeData(encodeURIComponent(data.CurentFolder + data.FolderNames[i]));
//        });
//        liElem2.append(hrefElem2);
//        $("#foldersList").append(liElem2);
//    }
//    $("#filesList").empty();

//    if (data.FileNames !== null)
//    {
//        for (var j = 0; j < data.FileNames.length; j++)
//        {
//            var liElem3 = $('<li />');
//            liElem3.text(data.FileNames[j]);
//            $("#filesList").append(liElem3);
//        }
//    }

//};
